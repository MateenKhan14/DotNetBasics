﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicsOfDotNET
{
    internal class AbstractClassExample
    {
        int _myNumber;

        public int MyNumber { get => _myNumber; set => _myNumber = value; }
        // ArthMatic ar = new ArthMatic();

        public void Show()
        {
            Console.WriteLine(_myNumber);
        }

    }

    public abstract class  ArthMatic{

      public  abstract int Add(int a, int b);// only declaration
        public int Substract(int a, int b)
            {
                return a-b;
            }
    }

    public class ChildAbstract : ArthMatic
    {
        public override int Add(int a, int b)
        {
            return a + b;
        }
    }

    interface IMyInterface
    {
        int MyFunction();
    }
}


