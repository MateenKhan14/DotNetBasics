﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyAspDotnetFrameworkApp
{
    public partial class Employee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //TextBox1.Text = "Hello";
            ViewState["firstName"] = "Ranjeet";
            if (Page.IsPostBack)
            {

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            txtName.Text = myHiddenfield.Value;
                //ViewState["firstName"].ToString();

        }

        protected void txtName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}