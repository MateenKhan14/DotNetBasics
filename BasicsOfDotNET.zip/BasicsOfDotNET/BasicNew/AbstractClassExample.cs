﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicNew
{
    // Abstract class can have functions with defination and without defination(only declaration)
    // We cannot create object of Abstract Class
    // We have to inherit abstract class and then give defination to Abstract function

    internal abstract class AbstractClassExample
    {
        public abstract void ShowDetails();

        public void ShowMessage()
        {
            Console.WriteLine("Non abstract function ShowMessage called");
        }
    }

    internal class ChildClassAbs: AbstractClassExample
    {
        public override void ShowDetails()
        {
            Console.WriteLine("Show details function implemented");

        }
    }
}
