using AspDotNetCoreStudy.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace AspDotNetCoreStudy.Pages.EmployeeList
{
    public class IndexModel : PageModel
    {

        public IEnumerable<Employee>  Employees { get; set; }
        private ApplicationDBContext _db;

        public IndexModel(ApplicationDBContext db)
        {
            _db = db;
        }
        //this is handler method get
        public async Task OnGet()// Post 
        {
            //async will let run multiple task at a time untill it was awaited
            
            this.Employees = await _db.Employees
               .ToListAsync();
            // .Where(x=>x.Name.StartsWith("A"))
            // Employees=new List<Employee>();
            //((List<Employee>)Employees).Add(new Employee { EmpId = 1, Name = "Anil", Salary = 2000 });
            // ((List<Employee>)Employees).Add(new Employee { EmpId = 2, Name = "Sanjeet", Salary = 3000 });
        }

        public IActionResult OnPostDelete(int id)
        {
            if (ModelState.IsValid)
            {
                var empFromDBToRemove = _db.Employees.Find(id);
                _db.Employees.Remove(empFromDBToRemove);
                _db.SaveChanges();
                return RedirectToPage("Index");
            }
            else
            {
                return Page();
            }
        }


    }
}
