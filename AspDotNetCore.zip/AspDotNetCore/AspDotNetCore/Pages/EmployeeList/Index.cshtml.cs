using AspDotNetCoreStudy.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AspDotNetCoreStudy.Pages.EmployeeList
{
    public class IndexModel : PageModel
    {

        public IEnumerable<Employee>  Employees { get; set; }
        public void OnGet()// Post 
        {
            Employees=new List<Employee>();
           ((List<Employee>)Employees).Add(new Employee { EmpId = 1, Name = "Anil", Salary = 2000 });
            ((List<Employee>)Employees).Add(new Employee { EmpId = 2, Name = "Sanjeet", Salary = 3000 });
        }


    }
}
