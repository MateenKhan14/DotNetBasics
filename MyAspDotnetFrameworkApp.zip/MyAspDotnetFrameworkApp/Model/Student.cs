﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyAspDotnetFrameworkApp.Model
{
    public class Student
    {
        //private properties
        string _firstName;
        string _lastName;
        string _fathersName;
        string _address;
        string _course;

        public string FirstName { get => _firstName; set => _firstName = value; }
        public string LastName { get => _lastName; set => _lastName = value; }
        public string FathersName { get => _fathersName; set => _fathersName = value; }
        public string Address { get => _address; set => _address = value; }
        public string Course { get => _course; set => _course = value; }

        public Student(string firstName, string lastName, string fathersName, string address, string course)
        {
            this._firstName = firstName;
            this._lastName = lastName;
            this._fathersName = fathersName;
            this._address = address;
            this._course = course;
        }

        public Student()
        {
            
        }

        //public properties 

        //functions

    }
}