﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UseOfStatic
{
    internal  class SampleStaticClass
    {

         static SampleStaticClass()
        {
            Console.WriteLine("This is static constructor");

        }

        //Static property
        public static int MyStaticNumber;
       
        //Static function
        public static void Show()
        {
            Console.WriteLine("This is static function");
        }
    }
}
