﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicsOfDotNET
{
    //Access Modifier
    public class Student
    {
        //Properties
        //Functions

         int RollNo;
        public string Name;
        public string Course;
        public string Address;
        public bool IsFeesPaid;

        private void Calculate()
        {

        }
        public virtual void ShowDetails()
        {
            RollNo = 0;
            Calculate();
            Console.WriteLine("Name: "+ Name);
            Console.WriteLine("Course: " + Course);
            Console.WriteLine("Address: " + Address);
            Console.WriteLine("Is Fees Paid: " + IsFeesPaid);            
        }
    }


    public class Parent1
    {

    }
  internal class MedicalStudent:Student
    {
      public  string MedicineBranch;
        public override void ShowDetails()
        {
           
            Console.WriteLine("Medicine Branch: " + MedicineBranch);
           
        }
    }

    internal class EngineeringStudent : Student
    {
        public string EngineeringBranch;
        public override void ShowDetails()
        {

            Console.WriteLine("Engineering Branch: " + EngineeringBranch);

        }
    }
}
