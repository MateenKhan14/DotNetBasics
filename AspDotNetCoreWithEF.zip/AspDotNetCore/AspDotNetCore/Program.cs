using AspDotNetCoreStudy.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

#region MigrationCommands
//Migration Commands
//Commands:
//�	add - migration addEmployeeToDB
//�	update - Database
//�	Remove - Migration

#endregion




var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages(); // DI

//var myConnectionString = builder.Configuration.GetConnectionString("DefaultConnection");
var myConnectionString = "Server=localhost;DataBase=StudyEF; User ID = sa; Password=swift@123; Trusted_Connection=True;TrustServerCertificate=True";

builder.Services.AddDbContext<ApplicationDBContext>(options => options.UseSqlServer(myConnectionString));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error"); //MW
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();//MW
app.UseStaticFiles();//MW

app.UseRouting();

app.UseAuthorization();//MW

app.MapRazorPages();

app.Run();
