﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicNew
{
    // All the functions in interface dont have any defination (body) only declaration is done
    // We cannot create Object of interface
    // we implement or inherit an interface in another class and then we have to give a defination of interface functions
    // Mutiple inheritance is only possible in c# using interface
    public interface InterfaceExample
    {
        public void ShowDetails();
     
    }


    public interface Interface2
    {
        public void ShowDetails();

    }
    public class ChildClass1:InterfaceExample, Interface2
    {
        public void ShowDetails()
        {
            Console.WriteLine("This is showdetail of child class 1");
        }
    }

    public class ChildClass2 : InterfaceExample
    {
        public void ShowDetails()
        {
            Console.WriteLine("This is showdetail of child class 2");
        }
    }
}
