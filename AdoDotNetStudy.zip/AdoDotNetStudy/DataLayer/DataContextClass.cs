﻿
using System.Data;
using System.Data.SqlClient;
using DataLayer.Model;

namespace DataLayer
{

    //Connection 
    //SQL Server : System.Data.SQLClient
    //<My SQL : System.Data.OLBC
    //MS ACCESS: OLEDB
    //Oracle: System.Data.Oracle Client
    //PostGres: 

    //ConnectedMode
    //ConnectionString:
    //SQl Connection
    //SQL Command 
    //SQL DataReader

    //Disconnected Mode
    //DataSet, datatable
    public class DataContextClass
    {
        //for sql authentication
        string myConnectionString = "Data Source = localhost; Initial Catalog = Study; User ID = sa; Password=swift@123; TrustServerCertificate=True; MultipleActiveResultSets=True;";

        ////for windows authentication
        //string cs = "Data Source=LAPTOP-MGGOC6QP\\SQLEXPRESS;Initial Catalog=record;Integrated Security=true";
        //SqlConnection con = new SqlConnection(cs);
        public List<Employee> ConnectWithDB()
        {
            List<Employee> employees = new List<Employee>();

        SqlConnection con= new SqlConnection(myConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from Employee", con);//con.CreateCommand();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                int id= (int)dr["Id"];
                string name= (string)dr["EmpName"];
                int salary = (int)dr["Salary"];
                employees.Add(new Employee(id, name, salary));
            }
            con.Close();
            return employees;
        }

        public int GetMaxSalary()
        {
//managed code
//unmanaged code
//IDisposable interface 
            //using 
            int maxSal = 0;
            using (SqlConnection con = new SqlConnection(myConnectionString))
            {
                SqlCommand cmd = new SqlCommand("select MAX(Salary) from Employee", con);//con.CreateCommand();
                con.Open();
                maxSal = (int)cmd.ExecuteScalar();

                con.Close();
            }
            return maxSal;
        }

        public void ExecuteNonQueryiExample()
        {

        }

        public void ExecuteSP()
        {
            using (SqlConnection con = new SqlConnection(myConnectionString))
            {
                SqlCommand cmd = new SqlCommand("prod_name");//con.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@Name", "SSD DRIVE"));
                cmd.Parameters.Add(new SqlParameter("@Price", "$300"));
                cmd.Parameters.Add(new SqlParameter("@Date", "25 August 14"));
                con.Open();
              ;
                int i = cmd.ExecuteNonQuery();
                if (i > 0)

                    con.Close();
            }

        }
    
      public void DatasetExample()
        {
            // username='Nitesh'; Drop Table Employee 
           // int intId = int.Parse(id);
          //  string id = "1 or 1=1";
            DataTable empTable = new DataTable();
            

            DataColumn empIdColumn = new DataColumn();
            empIdColumn.ColumnName = "id";
            empIdColumn.DataType=typeof(int);

            DataColumn empNameColumn = new DataColumn();    
            empNameColumn.ColumnName = "name";
            empNameColumn.DataType = typeof(string);


            DataColumn empSalColumn =new DataColumn();
            empSalColumn.ColumnName = "salary";
            empSalColumn.DataType = typeof(int);

            empTable.Columns.Add(empIdColumn);
            empTable.Columns.Add(empNameColumn);
            empTable.Columns.Add(empSalColumn);

            //empTable.Rows.Add(1, "Surya", 100);
            //empTable.Rows.Add(2, "Sanjeet", 200);
            //empTable.Rows.Add(3, "Priyansh", 300);

            DataSet ds = new DataSet();
            ds.Tables.Add(empTable);

            using (SqlConnection con = new SqlConnection(myConnectionString))
            //SqlConnection con = new SqlConnection(myConnectionString);
            {
                string queryString = "Select * from Employee";
                SqlDataAdapter adapter = new SqlDataAdapter(queryString, con);
                adapter.Fill(ds);
            }
               

            //foreach (DataTable dt in ds.Tables)
            //{
                foreach(DataRow dr in ds.Tables[1].Rows)
                {
                    Console.WriteLine("EmpID: {0} ",dr["id"]);
                    Console.WriteLine("Emp Name: {0} ", dr["EmpName"]);
                    Console.WriteLine("Emp Salary: {0} ", dr["salary"]);
                }
            //}


        }
    
    }
}
