﻿using System.ComponentModel.DataAnnotations;

namespace AspDotNetCoreStudy.Model
{
    public class Employee
    {

        //Annotation , Primarykey, Name not null 

        [Key]
        public int EmpId { get; set; }

        [Required]
        public string Name { get; set; }

        public int Salary { get; set; }
    }
}
