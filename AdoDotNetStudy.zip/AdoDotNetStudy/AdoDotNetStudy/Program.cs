﻿// See https://aka.ms/new-console-template for more information
using DataLayer;

DataContextClass dataContextClass = new DataContextClass();
//var employees=dataContextClass.ConnectWithDB();

//foreach (var item in employees)
//{
//    Console.WriteLine("Name: {0}, Salary {1}", item.Name, item.Salary);   

//}

//int maxSal=dataContextClass.GetMaxSalary();
dataContextClass.DatasetExample();
Console.ReadLine();
