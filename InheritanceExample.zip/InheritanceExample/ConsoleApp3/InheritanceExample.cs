﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class InheritanceExample
    {
    }

    public class Parent
    {
        int i;
        public Parent(int i)
        {
            this.i = i;
            Console.WriteLine("Parent cons");

        }
        public virtual void Show()
        {
            Console.WriteLine("This is Parent");
        }

        public virtual void Show(string arg)
        {
            Console.WriteLine("This is Parent" + arg);
        }

    }

    public class Child : Parent
    {

        public Child() : base(4)
        {
            Console.WriteLine("Child cons");

        }
        public override void Show()
        {
            Console.WriteLine("This is Child");
        }

    }

    interface ISampleInterface
    {
        public void Show();


    }

   public abstract class SampleAbstractClass
        {

        public abstract void Show();

        public void Show1()
        {
            Console.WriteLine("");
        }

    }

    // Public, private, internal, protected
}
