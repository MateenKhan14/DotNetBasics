﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicNew
{
    internal class OverLoadingExample
    {

        public int  Add()
        {
            Console.WriteLine("I am add function");
            Console.ReadLine();            
            return 1;
        }
        public void Add(string arg, int a, char b, bool y)
        {
            Console.WriteLine("I am overloaded ADD: "+ arg);
        }
    }
}
