﻿// See https://aka.ms/new-console-template for more information
using UseOfStatic;

Console.WriteLine("Hello, World!");
//SampleStaticClass.Show();

//SampleStaticClass sp = new SampleStaticClass();




//Datatype : Value type, refrence Type 