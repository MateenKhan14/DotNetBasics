﻿// See https://aka.ms/new-console-template for more information
using ConsoleApp3;
using System;

Parent obj1 = new Child();

//Parent p1 = new Parent();

obj1.Show();
//parent.Show();

Console.ReadLine();
