﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyAspDotnetFrameworkApp
{
    public partial class StudentDetail : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["number"] != null)
            {
             int   noOfPostBack = Convert.ToInt32(Request.Cookies["number"].Value);
            }
            //txtFirstName.Text = Session["lastName"].ToString();

            //    if (Request.QueryString["name"]!=null)
            //{
            //    txtFirstName.Text = Request.QueryString["name"];
            //}

            List<Student1> students = new List<Student1>();
            students.Add(new Student1 { Id=1,Name="Ankit"});
            students.Add(new Student1 { Id = 2, Name = "Animesh" });
            students.Add(new Student1 { Id = 3, Name = "Lokesh" });
            students.Add(new Student1 { Id = 4, Name = "Anil" });


            grdStudents.DataSource = students;
            grdStudents.DataBind();
        }

        protected void Menu2_MenuItemClick(object sender, MenuEventArgs e)
        {

        }
    }

    public class Student1
    {
        private int _Id;
        private string _Name;

        public int Id { get => _Id; set => _Id = value; }
        public string Name { get => _Name; set => _Name = value; }
    }
}