﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventStudy
{
    class Counter
    {
        private int threshold;
        private int total;

        public Counter(int passedThreshold)
        {
            threshold = passedThreshold;
            total = 7;
        }

        public void Add(int x)
        {
            total += x;
            if (total >= threshold)
            {
                //if(ThresholdReached!=null)
                //ThresholdReached.Invoke(this, EventArgs.Empty);


                ThresholdReachedEventArgs args = new ThresholdReachedEventArgs();
                args.Threshold = threshold;
                args.TimeReached = DateTime.Now;
                OnThresholdReached(args);
            }
        }
        protected virtual void OnThresholdReached(ThresholdReachedEventArgs e)
        {
            EventHandler<ThresholdReachedEventArgs> handler = ThresholdReached1;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        //public event EventHandler ThresholdReached;
        public event EventHandler<ThresholdReachedEventArgs> ThresholdReached1;
    }

    public class ThresholdReachedEventArgs : EventArgs
    {
        public int Threshold { get; set; }
        public DateTime TimeReached { get; set; }
    }

   // public delegate void ThresholdReachedEventHandler(Object sender, ThresholdReachedEventArgs e);
}

