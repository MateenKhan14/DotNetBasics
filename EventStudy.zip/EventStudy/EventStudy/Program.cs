﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventStudy
{
    internal class Program
    {
        
        static void Main(string[] args)
        {           
             Counter c = new Counter(10);
            c.ThresholdReached += abc;

            Console.WriteLine("press 'a' key to increase total");
            while (Console.ReadKey(true).KeyChar == 'a')
            {
                Console.WriteLine("adding one");
                c.Add(1);
            }
        }
        static void abc(object sender, EventArgs e)
        {
            Console.WriteLine("The threshold was reached.");
            //Environment.Exit(0);
        }


        
        //static void c_ThresholdReached(object sender, ThresholdReachedEventArgs e)
        //{
        //    Console.WriteLine("The threshold of {0} was reached at {1}.", e.Threshold, e.TimeReached);
        //    Environment.Exit(0);
        //}
    }


    public class DelegateStudy
    {
        public Predicate<int> MyPredicate;
        public void ProcessDelegate()
        {
            
            MyPredicate = predicateFunction;
            Console.WriteLine(MyPredicate(6));
        }
        bool predicateFunction(int a)
        {
            return a == 1;
        }

    }
}
