﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryGenericsStudy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //TryCatchStudy tr = new TryCatchStudy();
            //tr.Show();
            //int[] myArray = {1,2,3, 4, 5};

            //char[] myCharArray = new char[5];
            //myCharArray[0] = 'b';
            //myCharArray[1] = 'c';

            //string[] strings = new string[5];
            //strings[0] = "Anil";

            //Student[] students=new Student[5];

            //Student st = new Student();

            //for (int i = 0; i < myArray.Length; i++)
            //{
            //    Console.WriteLine(myArray[i]);
            //}

            //ArrayList arrayList = new ArrayList();
            //arrayList.Add(1);
            //arrayList.Add("Anil");
            //arrayList.Add(3);

            //foreach (var item in arrayList)
            //{
            //    Console.WriteLine(item);
            //}

            //HashTable
            Hashtable hs = new Hashtable();
            hs.Add(1, "Anil");
            hs.Add(2, "Surya");
            hs.Add(3, "Vineet");
            hs.Add(4, "Kunwar");

            foreach (var item in hs.Keys)
            {
                Console.WriteLine(item);
            }

           // Console.WriteLine(hs[3]);


            //string name= (string)hs[1];

            //Boxing, Unboxing  Generics


            Console.ReadLine();
        }
    }

    class Student
    {
        public string name;
    }

    // Array
    // ArrayList
    // HashTable,  === Dictionary
}
