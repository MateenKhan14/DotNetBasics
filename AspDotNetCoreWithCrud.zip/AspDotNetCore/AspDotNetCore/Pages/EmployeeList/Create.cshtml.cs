using AspDotNetCoreStudy.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AspDotNetCoreStudy.Pages.EmployeeList
{
    public class CreateModel : PageModel
    {
        private ApplicationDBContext _db;

        [BindProperty]
        public Employee Emp { get; set; }

        public CreateModel(ApplicationDBContext db)
        {
            _db = db;
        }
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if(ModelState.IsValid)
            {
              _db.Employees.Add(Emp);
                _db.SaveChanges();
                return RedirectToPage("Index");
            }
            else
            {
                return Page();
            }
        }
    }
}
