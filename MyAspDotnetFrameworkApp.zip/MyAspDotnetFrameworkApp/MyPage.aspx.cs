﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyAspDotnetFrameworkApp
{
    public partial class MyPage : System.Web.UI.Page
    {
        List<Student1> students = new List<Student1>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               
                students.Add(new Student1 { Id = 100, Name = "Ankit" });
                students.Add(new Student1 { Id = 200, Name = "Animesh" });
                students.Add(new Student1 { Id = 300, Name = "Lokesh" });
                students.Add(new Student1 { Id = 400, Name = "Anil" });
                grddata.DataSource = students;
                Session["StudentData"] = students;

                grddata.DataBind();
            }
        }

        protected void grddata_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int studentId =int.Parse(e.CommandArgument.ToString());
            Student1 stu=new Student1();

            List<Student1> myStudents = (List<Student1>)Session["StudentData"];
            foreach (var item in myStudents)
            {
                if (item.Id == studentId)
                {
                    stu = item;
                    break;
                }
            }
            students.Remove(stu);
        }
    }
}
