﻿// See https://aka.ms/new-console-template for more information

using LinqStudy;
using System.Security.Cryptography.X509Certificates;

int[] scores = { 97, 92, 81, 60, 92 };

#region DefineStudentCollection



IList<Student> studentList = new List<Student>();
Student student1 = new Student() { StudentID = 1, StudentName = "Moin" };
student1.EnrolledCourses.Add(new Course { CourseID = 1, CourseName = "Java" });
student1.EnrolledCourses.Add(new Course { CourseID = 2, CourseName = "Dotnet" });

Student student2 = new Student() { StudentID = 2, StudentName = "Z" };
student2.EnrolledCourses.Add(new Course { CourseID = 1, CourseName = "Java" });
student2.EnrolledCourses.Add(new Course { CourseID = 2, CourseName = "Dotnet" });

var student3 = new Student() { StudentID = 3, StudentName = "Amar" };
student3.EnrolledCourses.Add(new Course { CourseID = 3, CourseName = "Python" });


studentList.Add(student1);
studentList.Add(student2);
studentList.Add(student3);



#endregion

#region QueryExample

// Select * from Scores where soce>80
// Define the query expression.
                IEnumerable<int> scoreQuery =
                    from score in scores
                    where score > 80
                    select score;

//int[] scores = { 97, 92, 81, 60 };
IEnumerable<int> scoreQuery1= scores.Where(x => x > 80);

//foreach (var item in scoreQuery1)
//{
//    Console.WriteLine(item);
//}
// Execute the query.
#endregion


#region Where
//find student with name starting from A
// select * from Students where name like 'A%'
//var result = studentList.Where(x => x.StudentName.StartsWith('A'));
//var result =scores.Where(x => x > 80);
#endregion

#region select
//Select
//var stuNames =studentList.Select(x => new { x.StudentName, x.StudentID });
//foreach (var i in stuNames)
//{
//    Console.Write(i + " ");
//}
//var selCourse = studentList.Select(x => x.EnrolledCourses);
//var selManyCourse = studentList.SelectMany(x => x.EnrolledCourses);

//foreach (var lstCourse in selCourse)
//{
//    foreach (var course in lstCourse)
//    {
//        Console.WriteLine(course.CourseName);
//    }
//}

//foreach (var course in selManyCourse)
//{
//    Console.WriteLine(course.CourseName);

//}

#endregion

#region FirstLastAndSingle


//var stu=studentList.First(x => x.StudentName == "Priya");
//var stu1 = studentList.FirstOrDefault(x => x.StudentName == "Priya");

//var stu2 = studentList.SingleOrDefault(x => x.StudentName == "Amar");



#endregion


#region ElementAtGroupBy
//var ele = studentList.ElementAt(1);
//var ele1 = studentList.ElementAtOrDefault(4);


//var groupedStu = studentList.GroupBy(x => x.StudentName);

//var orderedStudent = studentList.OrderBy(x => x.StudentName);

var distictStu = scores.Distinct();


#endregion

#region AllAny

var allExample = studentList.All(x => x.StudentName.StartsWith("M"));
var anyExample = studentList.Any(x => x.StudentName.StartsWith("M"));

#endregion
Console.ReadLine();