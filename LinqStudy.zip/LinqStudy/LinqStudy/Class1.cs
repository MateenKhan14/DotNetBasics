﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqStudy
{
    internal class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }

        public List<Course> EnrolledCourses { get; set; }

        public Student()
        {
            EnrolledCourses = new List<Course>();   
        }
    }

    internal class Course
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
    }
}
