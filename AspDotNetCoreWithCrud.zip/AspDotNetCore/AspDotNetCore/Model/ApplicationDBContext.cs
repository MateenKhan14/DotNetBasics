﻿using Microsoft.EntityFrameworkCore;

namespace AspDotNetCoreStudy.Model
{
    public class ApplicationDBContext: DbContext
    {
       public  ApplicationDBContext(DbContextOptions<ApplicationDBContext> options):base(options)
        {

        }
        public DbSet<Employee> Employees { get; set; }
        // public DbSet<Department> Department { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//var myConnectionString = "Server=localhost;DataBase=Study1; User ID = sa; Password=swift@123; Trusted_Connection=True;";

//            optionsBuilder.UseSqlServer(myConnectionString);
//        }
    }
}
