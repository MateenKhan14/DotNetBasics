﻿// See https://aka.ms/new-console-template for more information
using BasicNew;
using BasicsOfDotNET;


InterfaceExample objInterface;

int type = 2;

if (type == 1)
{

    objInterface = new ChildClass1();
}
else
{
    objInterface = new ChildClass2();
}

objInterface.ShowDetails();



Console.ReadLine();