﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryGenericsStudy
{
    internal class TryCatchStudy
    {

        public void Show()
        {
            //exception handling
            try
            {
                int b = 0;
                int a = 25 / b;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                //throw;
            }
            finally
            {
                Console.WriteLine("Finally Called");
            }

        }
    }
}
