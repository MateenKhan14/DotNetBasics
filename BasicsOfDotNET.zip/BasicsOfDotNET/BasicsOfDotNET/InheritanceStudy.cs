﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicsOfDotNET
{
    internal class InheritanceStudy
    {
    }

    public class ParentClass
    {
        public void ShowMessage()
        {
            Console.WriteLine("Parent Show Message called");
        }

        //methold overloading 
        public void ShowMessage(string myName)
        {
            Console.WriteLine("Parent Show Message with para " + myName);

        }
    }

    public class ChildClass: ParentClass
    {

    }
}
