﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicsOfDotNET
{
    public class Calculator

    {
        public int a;
        public int b;
        private int divisor;
      public  int Add(int div)
        {
            divisor = div;
            int result = a + b;
            return result/ divisor;
        }

        public int Substract()
        {
           int result = a - b;
            return result;
        }

        public void Devide()
        {
            int result = a/ b;
            Console.WriteLine(result/ divisor);
          //  return result;
        }


    }
}
