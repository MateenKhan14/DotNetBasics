using AspDotNetCoreStudy.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AspDotNetCoreStudy.Pages.EmployeeList
{
    public class EditModel : PageModel
    {

        private ApplicationDBContext _db;
        [BindProperty]
        public Employee Emp { get; set; }
        public EditModel(ApplicationDBContext db)
        {
            _db = db;

        }

        public void OnGet(int id)
        {
            Emp = _db.Employees.Find(id);
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                var empFromDB =  _db.Employees.Find(Emp.EmpId);
                empFromDB.Name = Emp.Name;
                empFromDB.Salary = Emp.Salary;
                _db.SaveChanges();//data will be pushed to database
                return RedirectToPage("Index");
            }
            else
            {
                return Page();
            }
        }

    }
}
