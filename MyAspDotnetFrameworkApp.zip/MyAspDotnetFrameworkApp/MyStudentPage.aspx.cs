﻿using MyAspDotnetFrameworkApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace MyAspDotnetFrameworkApp
{

    //https://www.c-sharpcorner.com/UploadFile/8911c4/page-life-cycle-with-examples-in-Asp-Net/

    //https://www.c-sharpcorner.com/UploadFile/225740/introduction-of-session-in-Asp-Net/

    //https://www.c-sharpcorner.com/UploadFile/225740/application-state-in-Asp-Net/

    //http://asp.net-informations.com/ajax/ajax.htm
    //https://learn.microsoft.com/en-us/aspnet/core/?view=aspnetcore-7.0

    //https://learn.microsoft.com/en-us/previous-versions/aspnet/ecs0x9w5(v=vs.100)
    public partial class MyStudentPage : System.Web.UI.Page
    {
        int noOfPostBack = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
           // var app=Application["Username"].ToString();

            // System.Web.Profile.
            int i = 10;
            int j = i / 0;

            if (IsPostBack)
            {

                i++;
                if (Request.Cookies["number"] != null)
                {
                    noOfPostBack = Convert.ToInt32(Request.Cookies["number"].Value);
                    noOfPostBack++;
                }
                string name = myHiddenfield.Value;

                if (ViewState["firstName"] != null)
                {

                }
            }
            Response.Cookies["number"].Value = noOfPostBack.ToString();

        }

        protected void Page_Preinit(object sender,EventArgs e)
        {

        }

        protected void Page_Init(object sender, EventArgs e)
        {

        }

        protected void Page_InitComplete(object sender, EventArgs e)
        {

        }


        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            Student st = new Student();

            st.FirstName=txtFirstName.Text;
            st.LastName=txtLastName.Text;
            st.FathersName=txtFatherName.Text;
            st.Address= txtAddress.Text;
            st.Course=ddlCourse.SelectedValue;

            ViewState["firstName"]=st.FirstName;
            myHiddenfield.Value = st.FirstName;
            Session["lastName"]=st.LastName;

            Response.Redirect("MyPage.aspx?name="+ st.FirstName);
          // Response.Redirect("StudentDetail.aspx?name="+ st.FirstName);
            //DatabaseFile.AddStudent(st);

        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {

        }

        protected void Page_UnLoad(object sender, EventArgs e)
        {

        }


    }
}