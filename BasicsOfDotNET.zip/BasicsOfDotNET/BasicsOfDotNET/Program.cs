﻿// See https://aka.ms/new-console-template for more information
using BasicsOfDotNET;

#region commentedcode
// for loop example
// for(<initialization>;<condition;<incr/decre>)
//i++ --> i=i+1  11<=10
//for (int i = 1; i <= 10; i++)
//{
//    Console.WriteLine("My Name is Vishal");
//}

//While loop example
//<initialization>
//While(<condition>)
//body

//int i = 1;
//while(i <= 10)
//{
//    Console.WriteLine("while loop");
//    i++;
//}


// Functions 
//<returntype> FunctionName(argument)

////Student obj1 = new Student();
//////obj1.RollNo = 1;
////obj1.Course = "Surgery";
////obj1.Name = "Upasana";
////obj1.Address = "Vasundra";
////obj1.IsFeesPaid = true;
////obj1.ShowDetails();

////Student obj1=new Student();
////obj1.RollNo = 1;
////obj1.Course = "Dot Net";
////obj1.Name = "Upasana";
////obj1.Address = "Vasundra";
////obj1.IsFeesPaid=true;

////obj1.ShowDetails();
////Console.WriteLine("---------------------------------------");
////Student obj2 = new Student();
////obj2.RollNo = 2;
////obj2.Course = "Dot Net";
////obj2.Name = "Divya";
////obj2.Address = "Sector 59";
////obj2.IsFeesPaid = false;

////obj2.ShowDetails();


////int Add( int a, int b)
////{ 
////    int result = a + b;
////    return result;
////}

////void MultiplyNumber()
////{
////    int myNumber = 6;

////    for (int i = 1; i <= 10; i++)
////    {
////        Console.WriteLine(myNumber * i);


////    }

////}

////MultiplyNumber();

////int rt=Add(3, 4);

//Calculator objCal=new Calculator();
//objCal.a = 20;
//objCal.b = 10;
//int addResult = objCal.Add();
//Console.WriteLine(addResult);
// objCal.Devide();


//Console.ReadLine();
////ParentClass p1 = new ParentClass();
////p1.ShowMessage();
////p1.ShowMessage("Hello");


////AbstractClassExample ab = new AbstractClassExample();
////ab.MyNumber = 100;
////ab.Show();

////int inputNumber = 5;

////for (int i = 1; i <= 10; i++)
////{
////    if (i == 5 || i==2)
////        continue;


////    Console.WriteLine( i);
////}

//////Switch Case example

////string dayOfWeek = "";

////if(dayOfWeek=="Monday")
////{
////    Console.WriteLine("Go to College");
////}
////else if(dayOfWeek=="Tuesday")
////{
////    Console.WriteLine("Go to Shop");

////}
////else if(dayOfWeek == "Saturday" && dayOfWeek == "Sunday")
////{
////    Console.WriteLine("Go to Ducat");
////}

////switch (dayOfWeek)
////{
////    case "Monday":
////        Console.WriteLine("Go to College");
////        break;
////    case "Tuesday":
////        Console.WriteLine("Go to College");
////        break;
////    case "Saturday":
////        Console.WriteLine("Go to College");
////        break;
////    default:
////        break;
////}
//////int b = 2+ 3
//////string abc= "Hello" + "Word" 
////int[] arr1 = new int[5];
////arr1[0] = 100;
////arr1[4] = 200;
#endregion


Student vishal;

int type=1;

if (type == 1)
{

    vishal = new MedicalStudent();
    vishal.Name = "Vishal";
    vishal.Course = "Medicine";
    vishal.Address = "Noida";
    vishal.IsFeesPaid = true;
    
    vishal.ShowDetails();
}
else if (type == 2)
{
    vishal = new EngineeringStudent();
    vishal.Name = "Vishal";
    vishal.Course = "Engineering";
    vishal.Address = "Noida";
    vishal.IsFeesPaid = true;
   ((EngineeringStudent)vishal).EngineeringBranch = "CS";
    vishal.ShowDetails();
}
else
{
    Console.WriteLine("Wrong type provided");
}



